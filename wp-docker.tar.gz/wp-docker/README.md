# WordPress CSRF + XSS

This is a vulnerabile WordPress by plugin which remote attacker can exploit the administrator to gain privilege

## Install
```
chmod +x install.sh
bash install.sh
```
