tar xfv wp-content.tar.gz

docker-compose up
